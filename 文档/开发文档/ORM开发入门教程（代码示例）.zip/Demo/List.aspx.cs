﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeiSha.Common;
using WeiSha.Data;
namespace Demo
{
    public partial class List : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = Gateway.Default.From<Song.Entities.Book>()
                    .ToArray<Song.Entities.Book>();
                GridView1.DataBind();
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //sender即按钮，但是需要转换一下类型
            Button btn = (Button)sender;
            //获取数据记录的id
            string id = btn.CommandArgument;

            //删除记录，通过数据记录的id
            //Song.Entities.Book._.ID == id 是删除条件
            Gateway.Default.Delete<Song.Entities.Book>(Song.Entities.Book._.ID == id);

            this.Alert("成功删除!");

            //重新绑定数据列
            GridView1.DataSource = Gateway.Default.From<Song.Entities.Book>()
               .ToArray<Song.Entities.Book>();
            GridView1.DataBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //sender即按钮，但是需要转换一下类型
            Button btn = (Button)sender;
            //获取数据记录的id
            string id = btn.CommandArgument;
            //跳转到编辑页，并带上当前记录的Id
            Response.Redirect("edit.aspx?id="+id);
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("add.aspx");
        }
    }
}