﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeiSha.Common;
using WeiSha.Data;

namespace Demo
{
    public partial class Add : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //创建书本的对象
            Song.Entities.Book book = new Song.Entities.Book();
            //将界面上填写的信息，填充到书本对象
            book = WeiSha.Common.Data.EntityFill(this, book) as Song.Entities.Book;
            //将填写的信息，保存到数据库
            Gateway.Default.Save<Song.Entities.Book>(book);

            //弹出提示信息
            this.Alert("添加成功！");
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}